package okowitz2b;

public interface Customer {

    public String getName(); 
    public String getEmail();

    /**
     * @return
     */
    public void customerInfo();
    
}
